# Clash内核
由于Clash的原始项目被删除，目前比较活跃的项目还有这么几个，可以在这里获取Clash内核可执行程序：

- [Clash官方版本](https://clash.wiki)
- [Clash.Meta](https://github.com/MetaCubeX/mihomo)

> 了解Clash配置知识，可以在这里找到相应的文档。


